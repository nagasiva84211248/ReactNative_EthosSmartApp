import { View, Text, FlatList, Image, StyleSheet, TouchableOpacity } from 'react-native';
import React, { useState } from 'react';
import { MSLDetailsinterface, UniqueProductFileOutput } from './interfaces';
import { Check_MSLplannedproduct_byFileId, Check_MSLplannedproduct_byGroupId, Delete_MSLplannedproduct_byFileId, Delete_MSLplannedproduct_ByGroupId, Insert_MSLPlannedproduct_Details } from '../services/dbServices';

interface EdetailSlideShowProps {
    MSLrelatedProductSlides: Array<UniqueProductFileOutput>;
    selectedMsl: MSLDetailsinterface | null;
}

const NUM_COLUMNS = 3;

const EdetailSlideShow: React.FC<EdetailSlideShowProps> = ({ MSLrelatedProductSlides, selectedMsl }) => {
    const [containerWidth, setContainerWidth] = useState(0);

    const handleLayout = (event: any) => {
        const { width } = event.nativeEvent.layout;
        setContainerWidth(width);
    };

    const _doSelectSlide = async (item: UniqueProductFileOutput) => {
        console.log("selected Slide for planning", item);
        console.log("selectedMsl", selectedMsl);
        if (selectedMsl != null) {
            let checkMSLProdGroupCount: any = await Check_MSLplannedproduct_byGroupId(item.ProductGroup_ID, '', 0, 0, selectedMsl);
            let checkMSLProdFileMandatoryCount: any = await Check_MSLplannedproduct_byFileId(item.ProductFile_ID, '', 0, 0, selectedMsl);
            if(checkMSLProdGroupCount[0].count > 0 && checkMSLProdFileMandatoryCount[0].count > 0 && item.ProductFile_Mandatory === true){ // Mandatory file exist in local database delete that productGroupId record
                console.log("1");
                await Delete_MSLplannedproduct_ByGroupId(item.ProductGroup_ID,selectedMsl);
            }else if(checkMSLProdGroupCount[0].count > 0 && checkMSLProdFileMandatoryCount[0].count > 0 && item.ProductFile_Mandatory === false){ // not Mandatory file exist in local database delete that productFile record
                console.log("2");
                await Delete_MSLplannedproduct_byFileId(item.ProductFile_ID,selectedMsl);
            }else if (checkMSLProdGroupCount[0].count > 0) { // Insert the product group with file ID details
                console.log("3");
                await Insert_MSLPlannedproduct_Details(item.ProductGroup_ID, item.ProductFile_ID, 0, 0, '', 0, 0, item.EdetailingLanguageId, selectedMsl);
            } else {
                console.log("4");
                if (checkMSLProdFileMandatoryCount[0].count === 0) { // Insert the selected product Record 
                console.log("5");
                    await Insert_MSLPlannedproduct_Details(item.ProductGroup_ID, item.ProductFile_ID, 0, 0, '', 0, 0, item.EdetailingLanguageId, selectedMsl);
                }
                // Insert the product files which are madatory = true 
                let mandatoryprodid: any = MSLrelatedProductSlides.filter(mp => mp.ProductFile_Mandatory == true && mp.ProductGroup_ID == item.ProductGroup_ID);
                mandatoryprodid.forEach(async (ele: any) => {
                    await Insert_MSLPlannedproduct_Details(item.ProductGroup_ID, ele.ProductFile_ID, 0, 1, '', 0, 0, item.EdetailingLanguageId, selectedMsl);
                });
            }
        }
    }

    const ITEM_WIDTH = containerWidth ? containerWidth / NUM_COLUMNS - 20 : 100;

    return (
        <View style={styles.mainContainer} onLayout={handleLayout}>
            {MSLrelatedProductSlides && MSLrelatedProductSlides.length > 0 ? (
                <FlatList
                    keyExtractor={(item) => item.ProductFile_ID.toString()}
                    data={MSLrelatedProductSlides}
                    numColumns={NUM_COLUMNS}
                    renderItem={({ item }) => (
                        <TouchableOpacity onPress={() => _doSelectSlide(item)}>
                            <View style={[styles.container, { width: ITEM_WIDTH }]}>
                                <Image
                                    style={styles.image}
                                    source={{ uri: `file://${item.ProductFile_ImageURL_localPath}` }}
                                    resizeMode="cover"
                                />
                            </View>
                        </TouchableOpacity>
                    )}
                />
            ) : (
                <Text>No record Found</Text>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1,
        paddingHorizontal: 10,
    },
    container: {
        height: 200,
        margin: 5,
        backgroundColor: 'lightgray',
    },
    image: {
        height: '100%',
        width: '100%',
    },
});

export default EdetailSlideShow;

