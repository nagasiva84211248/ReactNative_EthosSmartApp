interface LoginDetails {
    Login_ID: bigint,
    Employee_ID: bigint,
    Sub_Territory_ID: bigint,
    Division_ID: bigint,
    Division_Name: string,
    Designation_ID: bigint,
    Designation_Name: string,
    Employee_Name: string,
    EmployeeName: string,
    HeadQuarter_Name: string,
    Username: string,
    Password: string,
    Authentication: bigint,
    Authentication_Name: string,
    Sub_Territory_Name: string,
    Email: string,
    Mobile: string,
    Employee_Code: string,
    Segment: string,
    Total_MSl_Count: bigint,
    Profile_Image: string
}

interface EmployeeOutput {
    Authentication_ID: number
    Designation_ID: number
    Designation_Name: number
    Division_ID: number
    Division_Name: string
    Email: string
    EmployeeName: string
    Employee_Code: string
    Employee_ID: number
    Employee_Name: string
    Login_ID: number
    Mobile: number
    Reporting_Employee_ID: number
    Segment: string
    Sub_Territory_ID: number
    Sub_Territory_Name: string
    Total_MSl_Count: number
    toggleCheckBox: boolean
}

interface ModelMultiSelection {
    id: number,
    name: string,
    subteritoryId: number,
    languageId: number
    selected: number
    selectedLanguage: boolean,
    flag:string
}

interface ProductLanguage {
    languageId: number
    languageName: string
    selected: number
    selectedLanguage: boolean
}

interface ModalViewProps {
    visible: boolean;
    onClose: () => void;
    onSubmit: (selectedItems: ModelMultiSelection[]) => void;  
    data: Array<ModelMultiSelection>;
    resetCheckboxState: boolean; 
}

export type {
    LoginDetails,
    EmployeeOutput,
    ModelMultiSelection,
    ProductLanguage,
    ModalViewProps
}